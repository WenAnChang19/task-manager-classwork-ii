# Web App 個人課堂實作 II
B13901163 電機三 張玟銨

需要 Node.js 20 以上。
在本資料夾執行：
  npm ci
  npm start
瀏覽器開啟 http://localhost:2234
按 Ctrl+C 停止。npm test 執行 HTTP 整合測試。

勾選 checkbox 後按「更新」儲存。資料暫存在伺服器陣列，
重新整理保留，伺服器重啟清空。程式不需要資料庫。
SQL 題為獨立作業，請在教師指定的 W3Schools 編輯器執行 sql/ 各檔。

本 ZIP 僅包含可執行程式、測試及 SQL，不含 node_modules。
報告 PDF、截圖與 AI 使用紀錄另於完整 repo 保存：
https://github.com/WenAnChang19/task-manager-classwork-ii

Task I 介面及 CSS 來源：
https://github.com/WenAnChang19/task-manager-classwork
AI 工具 Codex 協助實作與驗證，完整揭露見獨立報告。
